import React from 'react';
import Constants from 'expo-constants';
import { StyleSheet, Text, View } from 'react-native';


export default function CalculatorShell(props) {
    // Navigation: props.navigation
    console.log(props.route);

    return (
        <View style={styles.container}>
            <Text style={styles.title}>{props.route.name}</Text>
            <Text style={styles.subtitle}>{props.route.params.description}</Text>
            <View style={styles.separator}/>
            <Text style={styles.text}>Calculator component</Text>
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        flexDirection: "column",
        backgroundColor: "#000",
        marginTop: Constants.statusBarHeight,
    },
    title: {
        textAlign: "center",
        color: "white",
        fontSize: 20,
        padding: 10,
        marginTop: 10,
    },
    subtitle: {
        textAlign: "center",
        color: "white",
        fontSize: 16,
        padding: 7,
    },
    separator: {
        margin: 3,
        marginTop: 10,
        marginBottom: 10,
        borderWidth: 1,
        borderColor: "#ff0000",
        borderStyle: "solid",
    },
    text: {
        color: "white",
        backgroundColor: "red",
        textAlign: "center",
    }
});
