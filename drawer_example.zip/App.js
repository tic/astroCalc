import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { createDrawerNavigator } from '@react-navigation/drawer';
import { NavigationContainer } from '@react-navigation/native';

import CalculatorShell from './screens/CalculatorShell.js';
import Settings from './screens/Settings.js';

// Import and register the necessary calculators
import ExampleCalculator from './components/calculators/ExampleCalculator.js';


let Calculators = [
    {
        name: "Example Calculator",
        description: "Provide two number values and the calculator outputs their sum as a single numerical value.",
        component: ExampleCalculator
    }
]

//

const Drawer = createDrawerNavigator();

const Paramify = details => ({
                                description: details.description,
                                component: details.component
                            });

const DrawerScreen = details => (<Drawer.Screen name={details.name}
                                                key={details.name}
                                                component={CalculatorShell}
                                                initialParams={Paramify(details)}/>);


export default function App() {
    return (
        <View style={styles.container}>
            <NavigationContainer>
                <Drawer.Navigator initialRouteName="Calculator">
                    {Calculators.map(calc => DrawerScreen(calc))}
                    <Drawer.Screen name="Settings" component={Settings}/>
                </Drawer.Navigator>
            </NavigationContainer>
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#000',
    },
});
